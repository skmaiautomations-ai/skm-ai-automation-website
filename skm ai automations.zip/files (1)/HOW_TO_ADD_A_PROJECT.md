# How to add a project to the website

The Projects section on the homepage reads from one file: `projects/projects.json`.
You don't need to touch `index.html` or write any code — just edit that file and drop in a screenshot.

## 1. Add your screenshot

Save an image of the project (a real screenshot, product photo, or mockup) into:

```
projects/images/your-project-name.png
```

Recommended: roughly 960×600px (16:10), JPG or PNG, under ~500KB so the page loads fast.

## 2. Add an entry to `projects/projects.json`

Open `projects/projects.json` in any text editor. It's a list of projects — copy one of the existing entries and edit it, or add a new block like this:

```json
{
  "title": "Your Project Name",
  "category": "AI chatbot",
  "description": "One or two sentences on what it does and the problem it solved.",
  "tags": ["Automation", "Integrations"],
  "image": "projects/images/your-project-name.png",
  "link": "https://example.com",
  "status": "Live"
}
```

Field notes:
- **title** — shown as the card heading.
- **category** — small label above the title (e.g. "Workflow automation", "Custom software").
- **description** — keep it short, 1–2 sentences.
- **tags** — up to 3–4 short keywords work best.
- **image** — the path to the screenshot you added in step 1.
- **link** — optional. Leave as `""` if there's nothing to link to; the "View project →" link only appears when this is filled in.
- **status** — optional badge on the image, e.g. `"Live"`, `"Case study"`, `"Internal tool"`.

Remember to add a comma after each entry except the last one in the list — that's the most common thing that breaks the file. If a JSON file ever fails to load, paste it into [jsonlint.com](https://jsonlint.com) to check for a typo.

## 3. Remove the sample projects

The three projects already in the file ("Ops Dashboard", "Support Assistant", "Lead Automation Pipeline") are placeholder mockups labeled **Sample** — delete those entries once you've added your first real project.

## 4. Viewing it locally

Browsers block a page from fetching a local JSON file when you just double-click `index.html` (a `file://` restriction, not a bug in the site). To preview changes on your own computer, run a tiny local server from the project folder:

```
python3 -m http.server 8000
```

then open `http://localhost:8000`. Once the site is deployed to real hosting (Netlify, Vercel, GitHub Pages, etc.), this isn't an issue — projects will load normally for every visitor.
